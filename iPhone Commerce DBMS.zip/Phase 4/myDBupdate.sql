update F21_S001_2_iPhone set manufacturing_price = '999'
where release_date = '2019-09-20';
update F21_S001_2_order set order_price = '1299'
where order_type = 'Online';