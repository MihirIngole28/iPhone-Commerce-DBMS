drop table F21_S001_2_Rates;
drop table F21_S001_2_Order_SWC;
drop table F21_S001_2_Order;
drop table F21_S001_2_Order_Map;
drop table F21_S001_2_iPhone;
drop table F21_S001_2_iPhone_initial_release;
drop table F21_S001_2_iPhone_model;
drop table F21_S001_2_Employee;
drop table F21_S001_2_Department;
drop table F21_S001_2_Customer;
drop table F21_S001_2_Store;
drop table F21_S001_2_Warehouse;
drop table F21_S001_2_Outlet;

