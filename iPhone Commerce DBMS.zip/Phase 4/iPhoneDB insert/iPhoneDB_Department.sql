insert into F21_S001_2_department values ('SLS001','Sales',150000);
insert into F21_S001_2_department values ('RND002','RnD',200000);
insert into F21_S001_2_department values ('MKT003','Marketing',100000);
insert into F21_S001_2_department values ('FIN004','Finance',175000);
