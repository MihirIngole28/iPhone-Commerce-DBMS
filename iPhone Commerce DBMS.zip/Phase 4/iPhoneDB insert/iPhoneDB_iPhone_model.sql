insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone X','2716 mAH','A11 Bionic Chip','7MP');
insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone 11','3110 mAH','A13 Bionic Chip','12MP');
insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone 11 Pro','3550 mAH','A13 Bionic Chip','12MP');
insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone 12','2775 mAH','A14 Bionic Chip','13MP');
insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone 12 Pro','2815 mAH','A14 Bionic Chip','14MP');
insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone 13','3227 mAH','A15 Bionic Chip','15MP');
insert into F21_S001_2_iPhone_model (Model_name,Battery,Processor,Camera) 
values('iPhone 13 Pro','3095 mAH','A15 Bionic Chip','16MP');
