How to execute the GUI for iPhone commerce DBMS.

Note: Change the user="<username>", password="<password>" to sqlplus username and password to execute the code.

Step 1: Ensure that the "insert.txt" file is present in the same path as the "main.py" file.

Step 2: Run the "main.py" file.

Step 3: After the connection is created choose option 1 (Refresh Database) from the main menu. This will drop all existing tables, 
	create new tables and insert records into all the tables. This may take upto 2 mins.

Step 4: Follow the menu and execute the results as per requirements.


Optional Step: 
Open the main.ipynb file in Jupyter Notebook and rull all cells. The output of the relations will be displayed in a elegant format.